class CartItem {
  final int productId;
  final String name;
  final String? imageUrl;
  final double price;
  final int quantity;
  final String unit;

  CartItem({
    required this.productId,
    required this.name,
    this.imageUrl,
    required this.price,
    required this.quantity,
    required this.unit,
  });

  factory CartItem.fromJson(Map<String, dynamic> json) {
    return CartItem(
      productId: json['product_id'] ?? 0,
      name: json['name'] ?? '',
      imageUrl: json['image_url'],
      price: (json['price'] ?? 0).toDouble(),
      quantity: json['quantity'] ?? 0,
      unit: json['unit'] ?? '',
    );
  }

  double get total => price * quantity;
}
