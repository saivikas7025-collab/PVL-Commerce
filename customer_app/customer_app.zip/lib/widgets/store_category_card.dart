import 'package:flutter/material.dart';

class StoreCategory {
  final String name;
  final IconData icon;
  StoreCategory({required this.name, required this.icon});
}

class StoreCategoryCard extends StatelessWidget {
  final StoreCategory category;

  const StoreCategoryCard({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: const Color(0xFF16A34A).withAlpha(30),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Icon(category.icon, color: const Color(0xFF16A34A)),
        ),
        const SizedBox(height: 4),
        Text(
          category.name,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
        ),
      ],
    );
  }
}
