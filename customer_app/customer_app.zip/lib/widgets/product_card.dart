import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../models/product.dart';
import '../providers/cart_provider.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback? onTap;

  const ProductCard({
    super.key,
    required this.product,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final quantity = cart.quantityFor(product);

    final hasDiscount =
        product.originalPrice != null && product.originalPrice! > product.price;

    final discount = hasDiscount
        ? (((product.originalPrice! - product.price) / product.originalPrice!) *
                100)
            .round()
        : 0;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: const Color(0xFFE8E8E8),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 5,
                child: Stack(
                  children: [
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF6F7F6),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: product.imageUrl != null &&
                              product.imageUrl!.isNotEmpty
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.network(
                                product.imageUrl!,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) {
                                  return _placeholder();
                                },
                              ),
                            )
                          : _placeholder(),
                    ),
                    if (discount > 0)
                      Positioned(
                        left: 5,
                        top: 5,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFF008A3E),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Text(
                            '$discount% OFF',
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Text(
                product.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.poppins(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  height: 1.2,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                product.unit,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.poppins(
                  fontSize: 9,
                  color: Colors.grey,
                ),
              ),
              const Spacer(),
              Row(
                children: [
                  Text(
                    '₹${product.price.toStringAsFixed(0)}',
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (hasDiscount) ...[
                    const SizedBox(width: 4),
                    Text(
                      '₹${product.originalPrice!.toStringAsFixed(0)}',
                      style: GoogleFonts.poppins(
                        fontSize: 8,
                        color: Colors.grey,
                        decoration: TextDecoration.lineThrough,
                      ),
                    ),
                  ],
                  const Spacer(),
                  _quantityControl(
                    context,
                    quantity,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _quantityControl(
    BuildContext context,
    int quantity,
  ) {
    final cart = context.read<CartProvider>();

    if (quantity == 0) {
      return SizedBox(
        height: 28,
        child: OutlinedButton(
          onPressed: () {
            cart.add(product);
          },
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
            ),
            side: const BorderSide(
              color: Color(0xFF008A3E),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          child: Text(
            'ADD',
            style: GoogleFonts.poppins(
              color: const Color(0xFF008A3E),
              fontSize: 9,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      );
    }

    return Container(
      height: 28,
      decoration: BoxDecoration(
        color: const Color(0xFF008A3E),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            onTap: () {
              cart.decrease(product);
            },
            child: const SizedBox(
              width: 24,
              height: 28,
              child: Icon(
                Icons.remove,
                color: Colors.white,
                size: 14,
              ),
            ),
          ),
          Text(
            '$quantity',
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w700,
            ),
          ),
          InkWell(
            onTap: () {
              cart.add(product);
            },
            child: const SizedBox(
              width: 24,
              height: 28,
              child: Icon(
                Icons.add,
                color: Colors.white,
                size: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _placeholder() {
    return const Center(
      child: Icon(
        Icons.shopping_basket_outlined,
        size: 36,
        color: Colors.grey,
      ),
    );
  }
}
