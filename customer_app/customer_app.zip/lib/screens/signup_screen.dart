import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../services/auth_service.dart';

class SignupScreen extends StatefulWidget {
  final String? initialPhone;
  const SignupScreen({super.key, this.initialPhone});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final otpController = TextEditingController();
  bool hidePassword = true;
  bool loading = false;
  bool otpSent = false;
  String? error;

  @override
  void initState() {
    super.initState();
    if (widget.initialPhone != null)
      phoneController.text = widget.initialPhone!;
  }

  Future<void> _sendOtp() async {
    final phone = phoneController.text.trim();
    if (phone.isEmpty) {
      setState(() => error = 'Enter phone number');
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      await AuthService.sendOtp(phone: phone);
      setState(() => otpSent = true);
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> _signup() async {
    final name = nameController.text.trim();
    final phone = phoneController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text;
    final otp = otpController.text.trim();
    if (name.isEmpty ||
        phone.isEmpty ||
        email.isEmpty ||
        password.isEmpty ||
        otp.isEmpty) {
      setState(() => error = 'All fields required');
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    final auth = context.read<AuthProvider>();
    try {
      await auth.signup(
          name: name, phone: phone, email: email, password: password, otp: otp);
      // Splash screen will redirect
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create account')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.person_add_alt_1_rounded, size: 64),
                const SizedBox(height: 20),
                const Text('Create your account',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                const SizedBox(height: 24),
                TextField(
                    controller: nameController,
                    decoration: const InputDecoration(
                        labelText: 'Full name',
                        prefixIcon: Icon(Icons.person_outline))),
                const SizedBox(height: 12),
                TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                        labelText: 'Phone number',
                        prefixIcon: Icon(Icons.phone_outlined))),
                const SizedBox(height: 12),
                TextField(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email_outlined))),
                const SizedBox(height: 12),
                TextField(
                    controller: passwordController,
                    obscureText: hidePassword,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                          onPressed: () =>
                              setState(() => hidePassword = !hidePassword),
                          icon: Icon(hidePassword
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined)),
                    )),
                const SizedBox(height: 16),
                if (!otpSent)
                  OutlinedButton(
                      onPressed: loading ? null : _sendOtp,
                      child: const Text('Send OTP'))
                else ...[
                  TextField(
                      controller: otpController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          labelText: '6-digit OTP',
                          prefixIcon: Icon(Icons.verified_outlined))),
                  TextButton(
                      onPressed: loading ? null : _sendOtp,
                      child: const Text('Resend OTP')),
                ],
                if (error != null) ...[
                  const SizedBox(height: 8),
                  Text(error!, style: const TextStyle(color: Colors.red))
                ],
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: !otpSent || loading ? null : _signup,
                  child: loading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Create account'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
