import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final qty = cart.quantityFor(product);
    return Scaffold(
      appBar: AppBar(title: const Text('Product Details')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 250,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.grey.shade100,
              ),
              child: product.imageUrl != null && product.imageUrl!.isNotEmpty
                  ? Image.network(product.imageUrl!, fit: BoxFit.cover)
                  : const Icon(Icons.image, size: 100),
            ),
            const SizedBox(height: 20),
            Text(product.name,
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            Text(product.unit, style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height: 10),
            Text('₹${product.price.toStringAsFixed(0)}',
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            Text(product.description,
                style: TextStyle(color: Colors.grey.shade700)),
            const SizedBox(height: 24),
            if (qty == 0)
              FilledButton.icon(
                onPressed: () => cart.add(product),
                icon: const Icon(Icons.add_shopping_cart),
                label: const Text('Add to Cart'),
              )
            else
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => cart.decrease(product),
                      child: const Icon(Icons.remove),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text('$qty',
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w800)),
                  ),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => cart.add(product),
                      child: const Icon(Icons.add),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
