import 'api_client.dart';
import '../models/order.dart';
import 'auth_service.dart';

class OrderService {
  static Future<List<Order>> getOrders() async {
    if (!await AuthService.validateSession()) return [];
    final data = await ApiClient.get('/orders');
    final orders = data['orders'] as List? ?? [];
    return orders.map((e) => Order.fromJson(e)).toList();
  }
}
