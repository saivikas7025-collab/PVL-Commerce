import 'package:flutter/foundation.dart';
import '../models/product.dart';

class CartItem {
  final Product product;
  int quantity;
  CartItem(this.product, [this.quantity = 1]);
  double get total => product.price * quantity;
}

class CartProvider extends ChangeNotifier {
  final Map<int, CartItem> _items = {};
  List<CartItem> get items => _items.values.toList(growable: false);
  int get itemCount => _items.values.fold(0, (s, i) => s + i.quantity);
  double get subtotal => _items.values.fold(0, (s, i) => s + i.total);
  int quantityFor(Product p) => _items[p.id]?.quantity ?? 0;
  void add(Product p) {
    _items.update(p.id, (i) {
      i.quantity++;
      return i;
    }, ifAbsent: () => CartItem(p));
    notifyListeners();
  }

  void decrease(Product p) {
    final i = _items[p.id];
    if (i == null) return;
    if (i.quantity <= 1)
      _items.remove(p.id);
    else
      i.quantity--;
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
