import 'package:flutter/foundation.dart';

class ApiConfig {
  static const webUrl = 'http://localhost:5000/api';
  static const androidEmulatorUrl = 'http://10.0.2.2:5000/api';

  static String get baseUrl {
    if (kIsWeb) return webUrl;
    if (defaultTargetPlatform == TargetPlatform.android)
      return androidEmulatorUrl;
    return webUrl;
  }
}
